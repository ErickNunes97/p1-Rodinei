from cadastro import cadastro

print("===================== Sistema de Notas =======================")
print("Seja bem-vindo ao sistemas de notas, para continuar \nbasta acessar o menu abaixo digitando uma das opções.")
print("Digite 1 para iniciar o programa: ")
print("==============================================================")

digito = int(input("Escreva o digito pro favor.... \n"))


while digito != 0:
    print("======================= Menu Principal =======================")
    print("+ 1 - Cadastrar                                              +")
    print("+ 2 - Atualizar Cadastro                                     +")
    print("+ 3 - Visualizar Cadastros                                   +")
    print("+ 4 - Visualizar gráfico com a quantidade de pessoas         +")
    print("+ 5 - Deletar Estado do Sistema                              +")
    print("+ 0 - Para Sair                                              +")
    print("==============================================================")
    opcao = int(input("Digite a opção desejada: "))

    if opcao == 1:
        cadastro()
